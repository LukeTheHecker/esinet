import mne
import numpy as np
import matplotlib.pyplot as plt
